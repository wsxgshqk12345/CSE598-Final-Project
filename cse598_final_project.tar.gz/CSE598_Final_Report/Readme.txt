Hi, this file is written to help you start on the code.

The code is written to do cloud detection and the cloud properties retrieval including the cloud fraction.
The cloud detection task includes traditional machine learning methods including LinearSVC, Random Forest, Gradient Boosting, DNN, etc. 
The cloud fraction retrieval task includes simulation-based DNN and the DNN itself.

You need to install the related packages using the following code:
pip install numpy matplotlib tensorflow pandas scipy scikit-learn keras h5py ipywidgets selenium owslib shap cartopy

